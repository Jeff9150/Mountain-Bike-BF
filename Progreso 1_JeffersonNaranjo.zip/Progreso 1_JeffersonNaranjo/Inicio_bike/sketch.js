var img;
var bf;
var soundFile;


function preload() {
  // initialize sound
  soundFile = loadSound('assets/pop.mp3');
}

function setup() {
  createCanvas(1440, 780);

  //textAlign(CENTER);
  //fill(100);
  //noStroke();
  text("Click to play sound", width / 2, height / 2);

  noCursor();
  bf = loadImage("assets/bf.png");

  img = loadImage("assets/PRINCIPAL.png");


  startbutton = createButton('PLAY');
  startbutton.position(1250, 400);
  //startButton.mousePressed(PLAY);

  button = createButton('CONTROLES');
  button.position(1230, 450);

  button = createButton('EXIT');
  button.position(1250, 500);



}

function draw() {
  background(0);
  // Displays the image at its actual size at point (0,0)
  imageMode(CORNER);
  image(img, 0, 0);
  imageMode(CENTER);

  image(bf, mouseX, mouseY, img.width, img.height);

}

function mousePressed() {
  // trigger sound
  soundFile.play();

}